
# Constants ---------------------------------------------------------------

CHARACTER_LIMIT <- 200

PUNCTUATION_REGEX <- '[\\Q.!"#$%&\'()*+,/:;<=>?@[]^_`{|}~\u00ab\u00bb\u2026\\E]|\\\\.|\\d' # Note the use of \\Q.\\E

EMPTY_DAY_PLOT_HEIGHT <- 20

NUMBER_OF_FACTORS <- 8
