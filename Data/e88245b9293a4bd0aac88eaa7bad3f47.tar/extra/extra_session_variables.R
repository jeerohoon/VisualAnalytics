cx_extra_reset_data()

search_arguments$extra_plot <- "regular"
search_arguments$subset_search <- FALSE
search_arguments$extra_chart_terms <- "placeholder--0"
