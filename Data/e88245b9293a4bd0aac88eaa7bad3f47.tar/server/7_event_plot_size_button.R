observeEvent(input$size_button, {
  session_variables$plot_size <- input$PLOTSIZE
})
