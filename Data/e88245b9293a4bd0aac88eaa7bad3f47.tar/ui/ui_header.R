shinydashboard::dashboardHeader(
    title = shiny::div('Corpus exploration tool', class = "tittel"),
    shinydashboard::dropdownMenuOutput("dropdownmenu")
)
