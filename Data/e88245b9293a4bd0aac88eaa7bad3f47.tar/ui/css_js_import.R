shiny::tags$head(
    shiny::includeCSS("js_css/explorer_css.css"),
    shiny::includeScript("js_css/box_width.js"),
    shiny::includeScript("js_css/enter_search.js"),
    shiny::includeScript("js_css/jquery.scrollTo.js")
)
