shiny::div(shinydashboard::tabBox(width = 6,
           id = "dokumentboks"), class = "class_doc_box")
