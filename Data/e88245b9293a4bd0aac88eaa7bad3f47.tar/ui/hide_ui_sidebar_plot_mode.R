if (DATE_BASED_CORPUS == FALSE) {
  shinyjs::hideElement(id = "modus")
  shinyjs::hideElement(selector = ".conditional_hr")
}
